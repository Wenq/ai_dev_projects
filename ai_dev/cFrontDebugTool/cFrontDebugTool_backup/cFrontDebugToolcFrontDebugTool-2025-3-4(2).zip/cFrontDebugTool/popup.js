// 存储配置的键名
const STORAGE_KEY = 'kdweb_cdn_value';
// 公共参数常量
const KCDC_PARAM = 'kdcdc';
const DEBUG_PARAM = 'kdweb_debug';  // 新增调试参数常量
const CDN_PARAM = 'kdweb_cdn';      // 新增CDN参数常量

document.addEventListener('DOMContentLoaded', function () {
  console.log('Popup initialized'); // 添加初始化日志

  // Debug模式按钮
  document.getElementById('debugBtn').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      const currentUrl = new URL(tabs[0].url);
      const urlParams = new URLSearchParams(currentUrl.search);

      // 检查是否已存在调试参数（使用常量）
      if (!urlParams.has(DEBUG_PARAM)) {
        const hasQuery = currentUrl.search !== '';
        currentUrl.search += (hasQuery ? '&' : '?') + DEBUG_PARAM + '=true';
        chrome.tabs.create({ url: currentUrl.href, index: tabs[0].index + 1 });
      } else {
        alert('当前环境已是debug模式');
        return;
      }
    });
  });

  // 旧开发平台按钮（根据当前页面生成新URL）
  document.getElementById('oldPlatform').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      try {
        const currentUrl = new URL(tabs[0].url);
        const urlParams = new URLSearchParams();
        urlParams.set('formId', 'pc_devportal_main');

        // 使用CDN常量
        const existingCdn = currentUrl.searchParams.get(CDN_PARAM);
        if (existingCdn) {
          urlParams.set(CDN_PARAM, existingCdn);
        }

        // 新增：保留原有kdcdc参数
        const existingKdcdc = currentUrl.searchParams.get(KCDC_PARAM);
        if (existingKdcdc) {
          urlParams.set(KCDC_PARAM, existingKdcdc);
        }

        const newUrl = `${currentUrl.origin}${currentUrl.pathname}?${urlParams.toString()}`;
        chrome.tabs.create({ url: newUrl, index: tabs[0].index + 1 });
      } catch (e) {
        console.error('URL解析失败:', e);
      }
    });
  });

  // 新开发平台按钮（根据当前页面生成新URL）
  document.getElementById('newPlatform').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      try {
        const currentUrl = new URL(tabs[0].url);
        const urlParams = new URLSearchParams();
        urlParams.set('formId', 'bos_devpn_portal_grid');

        // 使用CDN常量
        const existingCdn = currentUrl.searchParams.get(CDN_PARAM);
        if (existingCdn) {
          urlParams.set(CDN_PARAM, existingCdn);
        }

        // 新增：保留原有kdcdc参数
        const existingKdcdc = currentUrl.searchParams.get(KCDC_PARAM);
        if (existingKdcdc) {
          urlParams.set(KCDC_PARAM, existingKdcdc);
        }

        const newUrl = `${currentUrl.origin}${currentUrl.pathname}?${urlParams.toString()}`;
        chrome.tabs.create({ url: newUrl, index: tabs[0].index + 1 });
      } catch (e) {
        console.error('URL解析失败:', e);
      }
    });
  });

  // 新增运行单据按钮
  // 预览单据按钮逻辑修改
  document.getElementById('previewForm').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      // 获取用户选中的文本
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          return window.getSelection().toString().replace(/[^\w]/g, '');
        }
      }, ([selection]) => {
        try {
          const defaultFormId = selection?.result || '';
          const formId = prompt('请输入要预览单据的formId（标识）：', defaultFormId);

          if (formId) {
            const currentUrl = new URL(tabs[0].url);
            // 新增参数处理逻辑
            const urlParams = new URLSearchParams();
            urlParams.set('formId', encodeURIComponent(formId));

            // 保留原有 CDN 参数
            const existingCdn = currentUrl.searchParams.get(CDN_PARAM);
            if (existingCdn) {
              urlParams.set(CDN_PARAM, existingCdn);
            }

            // 保留原有 kdcdc 参数
            const existingKdcdc = currentUrl.searchParams.get(KCDC_PARAM);
            if (existingKdcdc) {
              urlParams.set(KCDC_PARAM, existingKdcdc);
            }

            const newUrl = `${currentUrl.origin}${currentUrl.pathname}?${urlParams.toString()}`;
            chrome.tabs.create({
              url: newUrl,
              index: tabs[0].index + 1
            });
          }
        } catch (e) {
          console.error('表单打开失败:', e);
        }
      });
    });
  });

  // 运行移动端单据按钮
  document.getElementById('previewMobileForm').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      // 获取用户选中的文本
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          return window.getSelection().toString().replace(/[^\w]/g, '');
        }
      }, ([selection]) => {
        try {
          const defaultFormId = selection?.result || '';
          const formId = prompt('请输入要预览mobile单据的formId（标识）：', defaultFormId);

          if (formId) {
            const currentUrl = new URL(tabs[0].url);
            // 构建新的URL参数
            const urlParams = new URLSearchParams({
              form: encodeURIComponent(formId)
            });

            // 保留原有 CDN 参数
            const existingCdn = currentUrl.searchParams.get(CDN_PARAM);
            if (existingCdn) {
              urlParams.set(CDN_PARAM, existingCdn);
            }

            // 保留原有kdcdc参数
            const existingKdcdc = currentUrl.searchParams.get(KCDC_PARAM);
            if (existingKdcdc) {
              urlParams.set(KCDC_PARAM, existingKdcdc);
            }

            const newUrl = `${currentUrl.origin}${currentUrl.pathname}mobile.html?${urlParams.toString()}`;
            chrome.tabs.create({ url: newUrl, index: tabs[0].index + 1 });
          }
        } catch (e) {
          console.error('表单打开失败:', e);
        }
      });
    });
  });

  // 挂载本地环境按钮
  document.getElementById('loadLocalEnv').addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.storage.local.get([STORAGE_KEY], function (result) {
        const currentUrl = new URL(tabs[0].url);
        // 使用调试参数常量
        if (currentUrl.searchParams.has(DEBUG_PARAM)) {
          currentUrl.searchParams.delete(DEBUG_PARAM);
        }

        if (cachedValue) {
          applyCdnConfig(currentUrl, cachedValue, tabs[0].index);
        } else {
          const userInput = prompt('请输入本地环境CDN地址：', 'http://localhost:3000/ierp/feature_dev');
          if (userInput) {
            chrome.storage.local.set({ [STORAGE_KEY]: userInput }, function () {
              applyCdnConfig(currentUrl, userInput, tabs[0].index);
            });
          }
        }
      });
    });
  });

  // 设置按钮
  document.getElementById('localSettingsBtn').addEventListener('click', function () {
    //   alert('按钮点击成功'); // 先测试是否能触发点击事件
    chrome.storage.local.get([STORAGE_KEY], function (result) {
      const userInput = prompt('设置本地环境CDN地址：', result[STORAGE_KEY] || 'http://localhost:3000/ierp/feature_dev');
      if (userInput) {
        chrome.storage.local.set({ [STORAGE_KEY]: userInput });
      }
    });
  });

  // 公共处理函数
  function applyCdnConfig(currentUrl, cdnValue, tabIndex) {
    currentUrl.searchParams.set(CDN_PARAM, cdnValue);  // 使用CDN常量
    chrome.tabs.create({
      url: currentUrl.href,
      index: tabIndex + 1
    });
  }

  // 在DOMContentLoaded回调中添加
  const dropdownBtn = document.getElementById('openTestEnv');
  const dropdownMenu = document.querySelector('.dropdown-menu');

  // 生成下拉项
  Object.entries(ENVIRONMENTS).forEach(([key, env]) => {
    const li = document.createElement('li');
    li.textContent = env.des;
    li.addEventListener('click', () => {
      chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
        chrome.tabs.create({
          url: env.address,
          index: tabs[0].index + 1
        });
      });
    });
    dropdownMenu.appendChild(li);
  });

  // 切换下拉菜单
  dropdownBtn.addEventListener('click', () => {
    document.querySelector('.dropdown').classList.toggle('active');
  });

  // 点击外部关闭
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.dropdown')) {
      document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
    }
  });

  //DOMContentLoaded结束
});

// 在DOMContentLoaded回调中添加
const mountBtn = document.getElementById('mountTestEnv');
const mountMenu = mountBtn.nextElementSibling;

// 生成下拉项
Object.entries(ENVIRONMENTS).forEach(([key, env]) => {
  const li = document.createElement('li');
  li.textContent = env.des;
  li.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      try {
        const currentUrl = new URL(tabs[0].url);
        currentUrl.searchParams.set(CDN_PARAM, env.address);  // 使用CDN常量
        chrome.tabs.create({
          url: currentUrl.href,
          index: tabs[0].index + 1
        });
      } catch (e) {
        console.error('URL处理失败:', e);
      }
    });
  });
  mountMenu.appendChild(li);
});

// 切换下拉菜单（复用原有逻辑）
mountBtn.addEventListener('click', (e) => {
  // 移除 e.stopPropagation() 以允许事件冒泡
  document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('active'));
  mountBtn.parentElement.classList.add('active');
});

// 添加下拉面板控制逻辑（同时处理两个按钮）
function setupDropdown(buttonId) {
  const btn = document.getElementById(buttonId);
  const menu = btn.nextElementSibling;

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
  });

  // 点击其他区域关闭面板
  document.addEventListener('click', (e) => {
    if (!btn.contains(e.target)) {
      menu.style.display = 'none';
    }
  });
}

// 初始化两个下拉按钮
document.addEventListener('DOMContentLoaded', () => {
  setupDropdown('openTestEnv');
  setupDropdown('mountTestEnv');  // 新增这行代码
});